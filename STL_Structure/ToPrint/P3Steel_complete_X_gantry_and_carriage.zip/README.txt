                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1975016
P3Steel complete X gantry and carriage by oderbang is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

UPDATE:
V2 of the gantry idler and motor mount is now in place and uploaded. These parts provide clearance for the carriage to clear the frame properly.

Here we have my custom proteins, 4 in total
X gantry Idler mount
X Gantry with Stepper Motor mount
X Carriage - including low profile bearing sleeve/mount
X Carriage Belt Grip mount - Custom made tool less belt mount

All parts are designed to be printed with strength at there core. As they are designed specificly for FDM printing no support material is required.
Due to the low contact area Brim is definatly recommended (I used 7mm)

You will notice that no mounting holed for the threaded nuts are on these models. This is becouse i have several some 3 holes some 4 ect so simply drill what you need It is recommended to infill 100% for this reason.

You may also notice the threaded rob nuts are mounted at the bottom. this is to accommodate for 300mm integrated lead screws that are a little too short for the P3steel frame. These proteins resolve that issue

I have made these parts twice now for 2 diffrent Prusai3 to P3Steel convertions
I will upload v2 when complete that will make better use of the print bed space to add abit more clearence.

Also included the original sketchup files (does not include the frame)

# Print Settings

Printer Brand: 3D Systems
Printer: Cube 3
Resolution: 0.2
Infill: 100